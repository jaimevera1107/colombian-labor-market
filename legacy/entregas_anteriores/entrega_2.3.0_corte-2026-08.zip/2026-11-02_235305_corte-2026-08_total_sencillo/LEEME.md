# ICML — archivos sencillos (corte a agosto de 2026)

Solo las columnas de cada cosa, sin columnas de trazabilidad ni auditoría. Salen de la entrega completa (carpeta
hermana, sin el sufijo `_sencillo`), que sí trae `MANIFEST.json` y `VERIFICACION.json`. Versión 2.3.0.dev0. Mismos dos
universos y misma estructura: `universo_censo/` y `universo_geih/`, con `laboral/`, `informalidad/` y `sectorial/`.

Cada tabla viene en **CSV** (UTF-8 con BOM, para que Excel muestre las tildes) y en **XLSX** (`Fecha` es una fecha de
Excel; los códigos como `05` se conservan como texto; en el CSV Excel puede convertirlos a número).

## Columnas

| Siglas | Significado |
|---|---|
| Fecha | Fecha del mes: su primer día (`1993-01-01`) |
| Año, Mes | Año y número de mes (1 a 12), para filtrar y armar tablas dinámicas |
| DPT / CIUDAD | Departamento / dominio urbano |
| Codigo | Código DANE de dos dígitos |
| Ocupados, Desocupados, Inactivos | Personas |
| PEA, PET, Poblacion | Fuerza de trabajo, edad de trabajar, población total |
| TD, TO, TGP | Tasa de desempleo, de ocupación y global de participación (proporciones) |
| Informales, Formales, TI | Ocupados informales y formales; tasa de informalidad (proporción) |
| Sector, Participacion | Código de sector y su participación en el empleo |

**Laboral**: Fecha, Año, Mes, [DPT|CIUDAD, Codigo], Ocupados, Desocupados, Inactivos, PEA, PET, Poblacion, TD, TO, TGP.
**Informalidad**: Fecha, Año, Mes, [DPT, Codigo], Poblacion, PET, PEA, Ocupados, Desocupados, Inactivos, Informales,
Formales, TI. En ciudades solo Ocupados, Informales, Formales y TI.
**Sectorial**: Fecha, Año, Mes, [DPT, Codigo], Sector, Ocupados, Participacion.

## Cobertura

33 territorios (departamentos o ciudades) × 404 meses (1993-01 a 2026-08); el nacional, 404 meses; el sectorial,
además × 15 sectores. Las filas van ordenadas por código y fecha.

En el universo GEIH departamental, **9 territorios** (Arauca, Casanare, Putumayo, San Andrés y Providencia, Amazonas,
Guainía, Guaviare, Vaupés y Vichada) tienen las tasas y participaciones **vacías de 2001-01 a 2013-12**: la GEIH no los
representa hasta 2014, los niveles son 0 y una tasa sobre cero no existe. La entrega completa lo marca con la columna
`cobertura_geih`.

## Método: empalmes de 2001-01 (versión 2.3.0.dev0)

Esta entrega usa el método adoptado que corrige el escalón de 2001-01, donde cambia el régimen de
medición (reconstrucción hasta 2000-12, anclaje al DANE desde 2001-01):

* **Informalidad:** se desplaza el tramo inobservado (1993-01 a 2000-12) una constante estimada en el quiebre
  (2,46 pp en la tasa nacional). El paso de un mes en 2001-01 baja de 2,78 a 0,32 pp.
* **Laboral:** se empalma la proporción de población en edad de trabajar (PET/población, quiebre de 1,6 pp) y los
  niveles se reconstruyen con las tasas intactas. El salto de ocupados en 2001-01 baja de +5,19 % a +2,80 %.
  La población y las tasas TD, TO y TGP no cambian.
* **Alcance:** cambian 1993-01 a 2000-12 en laboral, informalidad y sectorial; **desde 2001-01 todo es idéntico**
  a la vintage anterior. Los niveles de ocupados de 1993-2000 son entre 1,2 % y 3,8 % mayores que antes.
* Detalle y reversión: `docs/production/EMPALMES_2001.md`. Queda registrado en `MANIFEST.json` (`inputs_note`).

Las ciudades son iguales en ambos universos. No son estadísticas oficiales; el sectorial es experimental.
