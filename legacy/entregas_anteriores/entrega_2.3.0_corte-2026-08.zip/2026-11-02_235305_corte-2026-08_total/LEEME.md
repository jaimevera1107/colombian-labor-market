# ICML — entrega completa con corte a agosto de 2026, en dos universos

Generada el 2 de noviembre de 2026 (hora de Bogotá), versión 2.3.0.dev0, modo total. Investigación; **no son
estadísticas oficiales**. El producto sectorial es experimental. La carpeta hermana `..._sencillo` trae los mismos
datos solo con las columnas de cada cosa.

## Los dos universos

* `universo_censo/` — el territorio completo (población del CNPV 2018).
* `universo_geih/` — la parte del territorio que la GEIH representa.

Cada universo trae **laboral, informalidad y sectorial**. Cada archivo lleva en el nombre el nivel, el universo, el
corte y la fecha y hora de la ejecución.

## Cobertura

Todos los productos cubren **todos los meses de 1993-01 a 2026-08 (404 meses)**:

| Nivel | Territorios | Filas por archivo |
|---|---|---|
| Nacional | 1 (una serie por universo) | 404 |
| Ciudades | 33 | 13.332 |
| Departamentos | 33 | 13.332 |
| Sectorial nacional | 1 × 15 sectores | 6.060 |
| Sectorial departamental | 33 × 15 sectores | 199.980 |

`VERIFICACION.json` comprueba esto archivo por archivo (36 comprobaciones).

## `cobertura_geih`

En los archivos **departamentales del universo GEIH** cada fila dice cómo la GEIH cubre ese departamento en ese mes:

* `COMPLETA` — la GEIH representa todo el territorio.
* `PARCIAL` — representa solo una parte (las capitales desde 2014).
* `SIN_REPRESENTACION` — no representa a nadie: los niveles son 0 y las tasas y participaciones **no existen**, por
  lo que quedan vacías.

`SIN_REPRESENTACION` ocurre en 9 territorios (Arauca, Casanare, Putumayo, San Andrés y Providencia, Amazonas,
Guainía, Guaviare, Vaupés y Vichada) de 2001-01 a 2013-12: 1.404 territorio-mes. Antes de 2001 esos territorios se
reconstruyen completos, y desde 2014 la GEIH incorpora sus capitales. En el universo censo esos mismos territorios y
meses tienen todos los valores.

## Método: empalmes de 2001-01 (versión 2.3.0.dev0)

Esta entrega usa el método adoptado que corrige el escalón de 2001-01, donde cambia el régimen de
medición (reconstrucción hasta 2000-12, anclaje al DANE desde 2001-01):

* **Informalidad:** se desplaza el tramo inobservado (1993-01 a 2000-12) una constante estimada en el quiebre
  (2,46 pp en la tasa nacional). El paso de un mes en 2001-01 baja de 2,78 a 0,32 pp.
* **Laboral:** se empalma la proporción de población en edad de trabajar (PET/población, quiebre de 1,6 pp) y los
  niveles se reconstruyen con las tasas intactas. El salto de ocupados en 2001-01 baja de +5,19 % a +2,80 %.
  La población y las tasas TD, TO y TGP no cambian.
* **Alcance:** cambian 1993-01 a 2000-12 en laboral, informalidad y sectorial; **desde 2001-01 todo es idéntico**
  a la vintage anterior. Los niveles de ocupados de 1993-2000 son entre 1,2 % y 3,8 % mayores que antes.
* Detalle y reversión: `docs/production/EMPALMES_2001.md`. Queda registrado en `MANIFEST.json` (`inputs_note`).

## Notas

* **Ciudades**: son dominios urbanos de la GEIH y señales no aditivas. No existe una serie censal propia, así que la
  misma serie está en ambos universos.
* **Nacional GEIH (laboral)** es la cifra publicada por el DANE; las columnas `represented_sum_*` y
  `gap_published_minus_sum_*` la comparan con la suma de los departamentos representados (coinciden desde 2014).
* **Sectorial**: existe a nivel nacional y departamental.
* `MANIFEST.json` guarda el hash SHA-256 de cada archivo, el mapa columna original a columna entregada y la versión.
* `INFORME_RECALCULO_INTEGRAL.json` es el informe de la recalculación completa (auditoría cruzada de los ocho productos).
